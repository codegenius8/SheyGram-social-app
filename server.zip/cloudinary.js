const cloudinary = require('cloudinary')
cloudinary.config({ 
    cloud_name: 'dumxcefjt', 
    api_key: '925297557944553', 
    api_secret: '_7ISfMAYG6LQGv1fSta8DqC-Bj8' 
  });

  module.exports = {cloudinary};
